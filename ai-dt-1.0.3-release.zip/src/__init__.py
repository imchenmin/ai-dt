"""AI-Driven Test Generator for C/C++ code"""

__version__ = "1.0.3"