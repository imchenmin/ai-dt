"""AI-Driven Test Generator for C/C++ code"""

__version__ = "0.1.0"